var num = parseInt(prompt('Introduce un numero para ver su tabla de multiplicar'));

for (i = 0; i <= 10; i++) {
    console.log(`${num} x ${i} = ${num*i}`);
}