for (i = 0; i < 5; i++) {
    switch (i) {
        case 0:
            alert('Uno');
            break;
        case 1:
            alert('Dos');
            break;
        case 2:
            alert('Tres');
            break;
        case 3:
            alert('Cuatro');
            break;
        case 4:
            alert('Cinco');
            break;
    }
}