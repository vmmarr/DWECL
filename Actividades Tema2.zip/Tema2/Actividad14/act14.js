//var contra = '';
var c = 'contraseña';

do {
    var contra = prompt('Introduce la contaseña');
} while (contra.toLowerCase() != c.toLowerCase());

alert('Bienvenido');
