var num = parseInt(prompt('Intruduce un numero'));

if (num%2 == 0) {
    alert(`${num} es par`);
} else {
    alert(`${num} es impar`);
}