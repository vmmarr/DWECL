alert('Resultados que dan menos infinito');
alert(`Math.max() + Math.max() = ${Math.max() + Math.max()}`);
alert(`Math.min() * Math.max() = ${Math.min() * Math.max()}`);
alert(`Math.max() / 0 = ${Math.max() / 0}`); 

alert('Resultados que da infinito');
alert(`Math.max() * Math.max() = ${Math.max() * Math.max()}`);
alert(`Math.pow(Math.max(), 2) = ${Math.pow(Math.max(), 2)}`);
alert(`5/0 = ${5/0}`);

