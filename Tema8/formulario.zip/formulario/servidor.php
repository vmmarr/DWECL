<?php
	echo "Se ha recibido la información correctamente";
?>